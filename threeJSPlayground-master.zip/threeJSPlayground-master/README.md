
Personal testing ground for ThreeJS (WebGL) features

[threeJSPlayground](https://jcsilverio.github.io/threeJSPlayground)
