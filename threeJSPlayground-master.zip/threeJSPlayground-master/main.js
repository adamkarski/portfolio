


$("#button_01").click(function() {
 $("#threeViewer").html('<iframe src="grid.html" style="position:fixed; top:80px; left:0px; bottom:0px; right:0px; width:100%; height:100%; border:none; margin:0; padding:0; overflow:hidden; z-index:999999;"></iframe>');

 //<iframe src="mypage.html" style="position:fixed; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%; border:none; margin:0; padding:0; overflow:hidden; z-index:999999;">
   // Your browser doesn't support iframes
//</iframe>
});

$("#button_02").click(function() {
$("#threeViewer").html('<iframe src="grid_static.html" style="position:fixed; top:80px; left:0px; bottom:0px; right:0px; width:100%; height:100%; border:none; margin:0; padding:0; overflow:hidden; z-index:999999;"></iframe>');
});

$("#button_03").click(function() {
$("#threeViewer").html('<iframe src="mesh.html" style="position:fixed; top:80px; left:0px; bottom:0px; right:0px; width:100%; height:100%; border:none; margin:0; padding:0; overflow:hidden; z-index:999999;"></iframe>');
});